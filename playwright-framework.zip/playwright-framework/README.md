# Playwright Automation Framework

A senior-level UI test automation framework built on [Playwright](https://playwright.dev) + TypeScript, with structured logging, cross-run flaky-test intelligence, visual regression, MCP integration for Claude Code, and a CI pipeline that's ready to switch on.

It currently targets [saucedemo.com](https://www.saucedemo.com) as a placeholder application — the base URL and credentials are entirely environment-driven, so repointing it at your real app is a config change, not a code change (see [Repointing at your real app](#repointing-at-your-real-app)).

## What's inside

| Capability               | How                                                                                   |
| ------------------------ | ------------------------------------------------------------------------------------- |
| Cross-browser UI testing | chromium / firefox / webkit projects, web-first assertions, Page Object Model         |
| Interactive runner       | `npm start` — a guided menu; no Playwright flags to memorize                          |
| Structured logging       | winston, run-scoped log files per worker + per-test logs attached to the HTML report  |
| Flaky-test detection     | custom reporter tracks every run in a rolling history, computes per-test flake rates  |
| Automatic reruns         | CI-gated retries, `--last-failed` rerun script, flake-hunting script                  |
| Quarantine system        | `@quarantine` tag + committed ledger; known-flaky tests keep running without blocking |
| Visual regression        | built-in `toHaveScreenshot()` with platform-aware baselines                           |
| MCP integration          | Playwright MCP + Chrome DevTools MCP configured project-wide for Claude Code          |
| CI (dormant)             | GitHub Actions: sharded matrix, blob-report merge, flake summary — enable when ready  |

## Quick start

```bash
npm install
npx playwright install
npm start          # interactive menu — pick what to run
```

That's it. `env/.env.demo` ships committed defaults (public SauceDemo credentials), so nothing else needs configuring.

## Running tests

**The easy way** — `npm start` opens a menu: full suite, one browser, a specific spec file, visual, rerun-failures, quarantined, or the flaky-pipeline demo. It prints the underlying `npx playwright test ...` command before running it, so the flags are learnable.

**Direct scripts:**

| Command                                                 | What it does                                                  |
| ------------------------------------------------------- | ------------------------------------------------------------- |
| `npm test`                                              | Everything: chromium + firefox + webkit + visual + quarantine |
| `npm run test:chromium`                                 | UI suite, chromium only (fastest loop)                        |
| `npm run test:headed`                                   | Watch the browser while tests run                             |
| `npm run test:ui`                                       | Playwright UI mode (time-travel debugging)                    |
| `npm run test:visual`                                   | Visual regression suite                                       |
| `npm run test:rerun-failed`                             | Rerun **only** what failed last run                           |
| `npm run test:flake-hunt`                               | Run tests 10× with no retries to expose intermittents         |
| `npm run test:flaky-demo`                               | Deterministic demo of the flaky pipeline                      |
| `npm run test:quarantined`                              | Run quarantined tests only                                    |
| `npm run report`                                        | Open the HTML report                                          |
| `npm run lint` / `npm run typecheck` / `npm run format` | Code quality                                                  |

Run a single spec directly: `npx playwright test tests/ui/login.spec.ts --project=chromium`.

**From GitHub** (once the repo is pushed): Actions → _Playwright Tests_ → _Run workflow_ lets anyone with repo access run the whole suite or narrow it by project, spec path, or title pattern — no local setup needed.

## Project structure

```
src/
  config/env.ts          # dotenv layering + typed, validated env accessor
  fixtures/              # the ONLY import specs use: composed test + expect
  pages/                 # Page Object Model (BasePage contract + one class per page)
  reporters/             # flaky-reporter.ts — cross-run flake intelligence
  support/               # winston logger, flake-history helpers, global setup
tests/
  ui/                    # functional UI validation specs
  visual/                # toHaveScreenshot() specs + committed baselines
.github/workflows/       # dormant CI pipeline
scripts/                 # interactive runner, docker baseline helper
```

Dependency rule (enforced by review): **tests → fixtures → pages → (logger, env)**. Nothing points upward.

## Writing tests

Specs import exactly one module and receive ready-to-use page objects and a logger:

```ts
import { env } from '../../src/config/env';
import { expect, test } from '../../src/fixtures';

test('standard user can sign in', async ({ loginPage, inventoryPage, log }) => {
  await loginPage.goto();
  await loginPage.login(env.users.standard, env.password);
  await inventoryPage.expectLoaded();
  log.info('custom log lines land in the report attachment');
});
```

Conventions:

- **Locators**: `getByTestId()` first (the `data-test` attribute — configured via `testIdAttribute`), `getByRole()` second. No CSS/XPath unless there is no alternative.
- **Assertions**: web-first only (`await expect(locator).toBeVisible()`), and they live in specs — page objects expose locators and actions, plus one sanctioned `expectLoaded()` readiness check.
- **No `waitForTimeout`, no conditionals in tests** — ESLint enforces both.
- **Tags**: `test('title', { tag: '@quarantine' }, ...)` for quarantine; tags are filterable with `--grep` and visible in reports.

## Logging

Every run gets `logs/run-<RUN_ID>/worker-<n>.log` — one interleaved, human-readable file per worker. Every test also gets its own `test-log` attachment in the HTML report (open any test → Attachments), containing just that test's lines including retries. Use the `log` fixture inside tests; page objects log their actions automatically. Set `LOG_LEVEL=debug` for more detail.

## Flaky tests: detection → history → quarantine

**Detection.** On CI, tests retry up to 2× (`retries` in `playwright.config.ts`). A test that fails then passes on retry gets Playwright's `flaky` outcome — the authoritative signal the custom reporter (`src/reporters/flaky-reporter.ts`) records. See it live:

```bash
npm run test:flaky-demo
```

**History.** Every run appends to `.flaky-history/history.json` (rolling window of 50 runs; gitignored locally, persisted via `actions/cache` in CI). The reporter prints a ranked flake-rate table after each run, writes `.flaky-history/flaky-summary.json`, and on GitHub Actions adds a table to the run's summary page.

**Quarantine.** When a test is genuinely flaky and can't be fixed immediately:

1. Tag it: `test('cart badge updates', { tag: '@quarantine' }, ...)`
2. Add a ledger entry to `quarantine.json` (the reporter warns if tag and ledger disagree):

```json
{
  "key": "chromium::tests/ui/cart.spec.ts::Cart › cart badge updates",
  "reason": "badge count races the websocket push",
  "issue": "https://github.com/you/repo/issues/123",
  "since": "2026-08-31",
  "owner": "fayeem"
}
```

Quarantined tests leave the main browser matrix but keep running in the `quarantine` project (3 retries; in CI a `continue-on-error` job), so recovery is measurable. The reporter also **recommends** quarantine candidates: ≥30% flake rate over ≥5 runs. Release a test from quarantine after ~10 clean runs in the history.

**Enforcement dials** (both off by default — reporting first, gates when you're ready):

- `STRICT_FLAKY=1 npm test` — fail the run if _any_ test is flaky (`failOnFlakyTests`).
- The reporter's `budget` option in `playwright.config.ts` — fail only when a non-quarantined test's flake rate breaches a threshold.

## Rerunning failures

```bash
npm run test:rerun-failed    # reruns ONLY the tests that failed last run
```

State lives in `test-results/.last-run.json`. To chase an intermittent failure on one spec:

```bash
npm run test:flake-hunt -- tests/ui/cart.spec.ts
```

(10 repeats, no retries, one worker — every intermittent failure becomes visible.)

## Visual regression

```bash
npm run test:visual           # compare against baselines
npm run test:visual:update    # update baselines after an intentional UI change (changed only)
```

Baselines are **platform-aware** (`.../{projectName}/{platform}/name.png`), so your local macOS baselines and CI's Linux baselines coexist. Before enabling CI, generate the Linux set once — either `npm run test:visual:docker-update` (requires Docker; uses the exact CI image) or trigger the workflow with `update_snapshots: true` and commit the uploaded artifact. Review baseline diffs in git like any other change. Mask dynamic regions with `mask: [locator]` (see `storefront.visual.spec.ts`).

## MCP servers with Claude Code

`.mcp.json` configures two servers for everyone who opens this repo in Claude Code (first use prompts for approval):

- **playwright** (`@playwright/mcp`) — Claude drives a real browser: navigate, click, fill forms, take accessibility snapshots. The server runs with `--test-id-attribute=data-test`, so locators Claude suggests line up with this framework's `getByTestId()`.
- **chrome-devtools** (`chrome-devtools-mcp`) — performance traces with insight analysis, network/console inspection, CPU & network throttling (great for reproducing timing-based flakiness).

Typical workflows:

- _Generate a test_: "Navigate to the app, snapshot the page, and draft a spec for the checkout flow using our fixtures" — review the draft before committing.
- _Debug a selector_: "Open /inventory.html and show me the accessibility snapshot" — fix locators against the live DOM instead of guessing.
- _Investigate flakiness_: "Throttle the network to Slow 3G and walk through the login flow" — see what your assertions race against.

Windows note: npx-based MCP servers need `"command": "cmd", "args": ["/c", "npx", ...]`.

## CI pipeline

`.github/workflows/playwright.yml` is **functional but dormant** — only manual dispatch is live.

**To enable:** uncomment the `push:` / `pull_request:` triggers at the top of the workflow, generate Linux visual baselines (see above), and push. You get:

- A lint + typecheck gate, then a **4-way sharded** test matrix in the official Playwright container (version-locked to `package.json` — bump them together).
- A **quarantine job** that can never fail the workflow but still reports.
- A **merge job**: combines shard blob reports, runs the flaky reporter exactly once over the merged run, restores/saves flake history via cache, uploads the HTML report (30 days) and flaky summary, and writes the flake table to the run's summary page.

Scale sharding by editing the `shardIndex`/`shardTotal` matrix. Point at another environment per-run via the `base_url` dispatch input, or permanently via repo variables.

## Environment & configuration

Layering (first match wins): **real env vars → `.env` (gitignored) → `env/.env.<TEST_ENV>` (committed)**. `TEST_ENV` defaults to `demo`. All access goes through the typed `env` object in `src/config/env.ts`, which fails fast with a clear message when something's missing. `.env.example` documents every variable: `BASE_URL`, `TEST_ENV`, `SAUCE_*` credentials, `LOG_LEVEL`, `RETRIES`, `STRICT_FLAKY`.

## Repointing at your real app

1. Create `env/.env.staging` (copy `.env.demo`) with your `BASE_URL`; put secrets in `.env` or CI variables — never in git. Run with `TEST_ENV=staging npm test`.
2. Update `testIdAttribute` in `playwright.config.ts` to your app's convention (`data-testid`, `data-qa`, …) and the same flag in `.mcp.json`.
3. Replace the SauceDemo page objects/specs with your own, following the same patterns.
4. When per-test UI login gets slow, adopt Playwright's `storageState` + a setup project with `dependencies` — the fixture architecture doesn't change.
