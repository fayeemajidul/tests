import fs from 'node:fs';
import path from 'node:path';
import type {
  FullConfig,
  FullResult,
  Reporter,
  Suite,
  TestCase,
  TestError,
  TestResult,
} from '@playwright/test/reporter';
import {
  computeStats,
  isQuarantined,
  loadHistory,
  loadQuarantineLedger,
  saveHistory,
  trimHistory,
  type AttemptRecord,
  type FlakeStat,
  type RunRecord,
  type TestRunEntry,
} from '../support/flake-history';

export interface FlakyReporterOptions {
  /** Where history.json and flaky-summary.json live. Default: .flaky-history */
  historyDir?: string;
  /** Rolling window of runs to keep and compute rates over. Default: 50 */
  windowSize?: number;
  /** Committed quarantine ledger cross-referenced against @quarantine tags. */
  quarantineFile?: string;
  /** How many flaky tests to show in the console/step-summary tables. Default: 10 */
  topN?: number;
  /**
   * Optional enforcement: fail the run when a NON-quarantined test exceeds maxFlakeRate
   * after at least minRuns observations. Omitted = report-only (the default).
   */
  budget?: { maxFlakeRate: number; minRuns: number };
}

interface RunSummary {
  runId: string;
  flakyThisRun: string[];
  failedThisRun: string[];
  stats: FlakeStat[];
  quarantineWarnings: string[];
  quarantineCandidates: string[];
}

/**
 * Cross-run flaky-test intelligence. Per-attempt results are collected in onTestEnd; the
 * authoritative verdict is test.outcome() === 'flaky' in onEnd (failed at least once, then
 * passed on retry). Each run appends a RunRecord to a rolling history file, from which
 * per-test flake rates are computed and reported (console table, flaky-summary.json, and
 * GITHUB_STEP_SUMMARY when running in GitHub Actions).
 */
export default class FlakyReporter implements Reporter {
  private readonly historyDir: string;
  private readonly windowSize: number;
  private readonly quarantineFile: string;
  private readonly topN: number;
  private readonly budget?: { maxFlakeRate: number; minRuns: number };

  private suite!: Suite;
  private run!: Omit<RunRecord, 'tests'>;
  private readonly attempts = new Map<string, AttemptRecord[]>();

  constructor(options: FlakyReporterOptions = {}) {
    this.historyDir = options.historyDir ?? '.flaky-history';
    this.windowSize = options.windowSize ?? 50;
    this.quarantineFile = options.quarantineFile ?? 'quarantine.json';
    this.topN = options.topN ?? 10;
    this.budget = options.budget;
  }

  printsToStdio(): boolean {
    return true;
  }

  onBegin(config: FullConfig, suite: Suite): void {
    this.suite = suite;
    this.run = {
      runId: process.env.RUN_ID ?? new Date().toISOString().replace(/[:.]/g, '-'),
      startedAt: new Date().toISOString(),
      ci: !!process.env.CI,
      gitSha: process.env.GITHUB_SHA,
      branch: process.env.GITHUB_REF_NAME,
    };
  }

  onTestEnd(test: TestCase, result: TestResult): void {
    const key = this.testKey(test);
    const record: AttemptRecord = {
      retry: result.retry,
      status: result.status,
      durationMs: result.duration,
      error: result.error?.message?.split('\n')[0],
    };
    const list = this.attempts.get(key) ?? [];
    list.push(record);
    this.attempts.set(key, list);
  }

  onError(error: TestError): void {
    process.stderr.write(`[flaky-reporter] runner error: ${error.message ?? 'unknown'}\n`);
  }

  // The Reporter interface only accepts the exit-code override wrapped in a Promise.
  onEnd(_result: FullResult): Promise<{ status: FullResult['status'] } | undefined> {
    const ledger = loadQuarantineLedger(this.quarantineFile);
    const ledgerKeys = new Set(ledger.entries.map((entry) => entry.key));

    const tests: TestRunEntry[] = [];
    const flakyThisRun: string[] = [];
    const failedThisRun: string[] = [];
    const taggedQuarantineKeys = new Set<string>();

    for (const test of this.suite.allTests()) {
      const key = this.testKey(test);
      const outcome = test.outcome();
      if (test.tags.includes('@quarantine')) taggedQuarantineKeys.add(key);
      tests.push({ key, outcome, attempts: this.attempts.get(key) ?? [] });
      if (outcome === 'flaky') flakyThisRun.push(key);
      if (outcome === 'unexpected') failedThisRun.push(key);
    }

    const historyFile = path.join(this.historyDir, 'history.json');
    const history = trimHistory(
      { version: 1, runs: [...loadHistory(historyFile).runs, { ...this.run, tests }] },
      this.windowSize,
    );
    saveHistory(historyFile, history);

    const stats = computeStats(history, ledgerKeys);
    const quarantineWarnings = this.auditQuarantine(taggedQuarantineKeys, ledgerKeys);
    const quarantineCandidates = stats
      .filter((s) => !s.quarantined && s.runsSeen >= 5 && s.flakeRate >= 0.3)
      .map((s) => s.key);

    const summary: RunSummary = {
      runId: this.run.runId,
      flakyThisRun,
      failedThisRun,
      stats,
      quarantineWarnings,
      quarantineCandidates,
    };
    fs.writeFileSync(
      path.join(this.historyDir, 'flaky-summary.json'),
      JSON.stringify(summary, null, 2),
    );

    this.printSummary(summary, history.runs.length);
    this.writeStepSummary(summary, history.runs.length);

    if (this.budget) {
      const breach = stats.find(
        (s) =>
          !s.quarantined &&
          s.runsSeen >= this.budget!.minRuns &&
          s.flakeRate > this.budget!.maxFlakeRate,
      );
      if (breach) {
        process.stderr.write(
          `[flaky-reporter] flake budget breached by "${breach.key}" ` +
            `(rate ${(breach.flakeRate * 100).toFixed(0)}% over ${breach.runsSeen} runs)\n`,
        );
        return Promise.resolve({ status: 'failed' });
      }
    }
    return Promise.resolve(undefined);
  }

  private testKey(test: TestCase): string {
    const project = test.parent.project()?.name ?? 'unknown';
    const file = path.relative(process.cwd(), test.location.file);
    // titlePath() = [root, project, file, ...describes, title]; keep only the describe/title part.
    const titles = test.titlePath().filter(Boolean).slice(2).join(' › ');
    return `${project}::${file}::${titles}`;
  }

  private auditQuarantine(tagged: Set<string>, ledger: Set<string>): string[] {
    const warnings: string[] = [];
    for (const key of tagged) {
      if (!isQuarantined(key, ledger)) {
        warnings.push(`tagged @quarantine but missing from quarantine.json: ${key}`);
      }
    }
    for (const entry of ledger) {
      if (![...tagged].some((key) => key.includes(entry))) {
        warnings.push(
          `quarantine.json entry matches no @quarantine-tagged test in this run: ${entry}`,
        );
      }
    }
    return warnings;
  }

  private flakyRows(summary: RunSummary): FlakeStat[] {
    return summary.stats.filter((s) => s.flakyRuns > 0).slice(0, this.topN);
  }

  private printSummary(summary: RunSummary, runsInWindow: number): void {
    const rows = this.flakyRows(summary);
    const lines: string[] = [];
    lines.push('');
    lines.push(`[flaky-reporter] run ${summary.runId} — history window: ${runsInWindow} run(s)`);

    if (summary.flakyThisRun.length > 0) {
      lines.push(`[flaky-reporter] flaky THIS run (failed, then passed on retry):`);
      for (const key of summary.flakyThisRun) lines.push(`  ⚠ ${key}`);
    } else {
      lines.push('[flaky-reporter] no flaky tests this run');
    }

    if (rows.length > 0) {
      lines.push('[flaky-reporter] flakiest tests over the window:');
      lines.push('  rate   flaky/seen  quarantined  test');
      for (const s of rows) {
        const rate = `${(s.flakeRate * 100).toFixed(0)}%`.padStart(4);
        const ratio = `${s.flakyRuns}/${s.runsSeen}`.padStart(10);
        const quarantined = (s.quarantined ? 'yes' : 'no').padStart(11);
        lines.push(`  ${rate} ${ratio} ${quarantined}  ${s.key}`);
      }
    }

    for (const warning of summary.quarantineWarnings) {
      lines.push(`[flaky-reporter] WARNING: ${warning}`);
    }
    for (const key of summary.quarantineCandidates) {
      lines.push(`[flaky-reporter] RECOMMEND quarantine (>=30% flake rate over >=5 runs): ${key}`);
    }
    lines.push('');
    process.stdout.write(lines.join('\n'));
  }

  private writeStepSummary(summary: RunSummary, runsInWindow: number): void {
    const stepSummaryFile = process.env.GITHUB_STEP_SUMMARY;
    if (!stepSummaryFile) return;

    const rows = this.flakyRows(summary);
    const md: string[] = ['## Flaky test report', ''];
    md.push(
      `History window: **${runsInWindow} run(s)** · Flaky this run: **${summary.flakyThisRun.length}**`,
    );
    md.push('');
    if (rows.length > 0) {
      md.push('| Flake rate | Flaky/seen | Quarantined | Test |');
      md.push('|---|---|---|---|');
      for (const s of rows) {
        md.push(
          `| ${(s.flakeRate * 100).toFixed(0)}% | ${s.flakyRuns}/${s.runsSeen} | ${s.quarantined ? 'yes' : 'no'} | \`${s.key}\` |`,
        );
      }
    } else {
      md.push('No flaky tests in the history window. 🎉');
    }
    for (const warning of summary.quarantineWarnings) md.push(`> ⚠️ ${warning}`);
    for (const key of summary.quarantineCandidates)
      md.push(`> 🔁 Recommend quarantine: \`${key}\``);
    md.push('');
    fs.appendFileSync(stepSummaryFile, md.join('\n'));
  }
}
