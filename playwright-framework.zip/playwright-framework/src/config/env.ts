import path from 'node:path';
import dotenv from 'dotenv';

/**
 * Environment layering (first value wins — dotenv never overrides an existing key):
 *   1. Real process env (CI variables, inline overrides)
 *   2. .env               — local overrides, gitignored
 *   3. env/.env.<TEST_ENV> — committed per-environment defaults (TEST_ENV defaults to "demo")
 */

// CI systems often set inputs as empty strings (e.g. an optional workflow_dispatch input).
// Treat empty as unset so the dotenv layers below can fill the value in.
const KNOWN_KEYS = [
  'BASE_URL',
  'SAUCE_STANDARD_USER',
  'SAUCE_LOCKED_OUT_USER',
  'SAUCE_PASSWORD',
  'LOG_LEVEL',
  'TEST_ENV',
] as const;
for (const key of KNOWN_KEYS) {
  if (process.env[key] === '') delete process.env[key];
}

const TEST_ENV = process.env.TEST_ENV ?? 'demo';

dotenv.config({ path: path.resolve(process.cwd(), '.env'), quiet: true });
dotenv.config({ path: path.resolve(process.cwd(), 'env', `.env.${TEST_ENV}`), quiet: true });

function required(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(
      `Missing required environment variable ${name}. ` +
        `Set it in your shell, .env, or env/.env.${TEST_ENV} (see .env.example).`,
    );
  }
  return value;
}

export const env = {
  testEnv: TEST_ENV,
  baseUrl: required('BASE_URL'),
  users: {
    standard: required('SAUCE_STANDARD_USER'),
    lockedOut: required('SAUCE_LOCKED_OUT_USER'),
  },
  password: required('SAUCE_PASSWORD'),
  logLevel: process.env.LOG_LEVEL ?? 'info',
} as const;
