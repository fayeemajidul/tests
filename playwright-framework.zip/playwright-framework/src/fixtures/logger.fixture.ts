import { Writable } from 'node:stream';
import { test as base } from '@playwright/test';
import winston, { type Logger } from 'winston';
import { logger, logLine } from '../support/logger';

export interface LoggerFixtures {
  log: Logger;
}

/**
 * Auto fixture: every test gets a child logger tagged with its title (and retry number).
 * The test's own lines are captured through a per-test stream transport and attached to
 * the HTML report, while still flowing into the shared worker log for interleaved debugging.
 */
export const test = base.extend<LoggerFixtures>({
  log: [
    async ({}, use, testInfo) => {
      const testName =
        testInfo.retry > 0 ? `${testInfo.title} (retry ${testInfo.retry})` : testInfo.title;

      const chunks: string[] = [];
      const capture = new Writable({
        write(chunk: Buffer, _encoding, callback) {
          chunks.push(chunk.toString());
          callback();
        },
      });
      const captureTransport = new winston.transports.Stream({
        stream: capture,
        format: winston.format.combine(
          winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
          winston.format.errors({ stack: true }),
          logLine,
        ),
      });

      logger.add(captureTransport);
      const log = logger.child({ testName });
      log.info('test started');

      try {
        await use(log);
      } finally {
        log.info(`test finished: ${testInfo.status ?? 'unknown'}`);
        logger.remove(captureTransport);
        await testInfo.attach('test-log', {
          body: chunks.join(''),
          contentType: 'text/plain',
        });
      }
    },
    { auto: true },
  ],
});
