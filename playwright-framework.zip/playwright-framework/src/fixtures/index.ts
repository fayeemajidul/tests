/**
 * The single import surface for specs:
 *
 *   import { test, expect } from '../../src/fixtures';
 *
 * `test` composes the logger fixture (auto, per-test child logger attached to the report)
 * and the page-object fixtures (loginPage, inventoryPage, cartPage).
 */
export { test } from './pages.fixture';
export type { PageFixtures } from './pages.fixture';
export type { LoggerFixtures } from './logger.fixture';
export { expect } from '@playwright/test';
