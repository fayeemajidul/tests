import { test as loggerTest } from './logger.fixture';
import { CartPage } from '../pages/cart.page';
import { InventoryPage } from '../pages/inventory.page';
import { LoginPage } from '../pages/login.page';

export interface PageFixtures {
  loginPage: LoginPage;
  inventoryPage: InventoryPage;
  cartPage: CartPage;
}

export const test = loggerTest.extend<PageFixtures>({
  loginPage: async ({ page, log }, use) => {
    await use(new LoginPage(page, log));
  },
  inventoryPage: async ({ page, log }, use) => {
    await use(new InventoryPage(page, log));
  },
  cartPage: async ({ page, log }, use) => {
    await use(new CartPage(page, log));
  },
});
