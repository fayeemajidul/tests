import { expect, type Locator } from '@playwright/test';
import { BasePage } from './base.page';

export type SortOption = 'az' | 'za' | 'lohi' | 'hilo';

export class InventoryPage extends BasePage {
  readonly path = '/inventory.html';

  readonly title = this.page.getByTestId('title');
  readonly sortDropdown = this.page.getByTestId('product-sort-container');
  readonly items = this.page.getByTestId('inventory-item');
  readonly itemNames = this.page.getByTestId('inventory-item-name');
  readonly itemPrices = this.page.getByTestId('inventory-item-price');
  readonly cartBadge = this.page.getByTestId('shopping-cart-badge');
  readonly cartLink = this.page.getByTestId('shopping-cart-link');

  async expectLoaded(): Promise<void> {
    await expect(this.title).toHaveText('Products');
  }

  item(name: string): Locator {
    return this.items.filter({ hasText: name });
  }

  async addToCart(name: string): Promise<void> {
    this.log.info(`add to cart: "${name}"`);
    await this.item(name).getByRole('button', { name: 'Add to cart' }).click();
  }

  async removeFromCart(name: string): Promise<void> {
    this.log.info(`remove from cart: "${name}"`);
    await this.item(name).getByRole('button', { name: 'Remove' }).click();
  }

  async sortBy(option: SortOption): Promise<void> {
    this.log.info(`sort inventory: ${option}`);
    await this.sortDropdown.selectOption(option);
  }

  async openCart(): Promise<void> {
    this.log.info('open cart');
    await this.cartLink.click();
  }

  async visibleNames(): Promise<string[]> {
    return this.itemNames.allTextContents();
  }

  async visiblePrices(): Promise<number[]> {
    const raw = await this.itemPrices.allTextContents();
    return raw.map((text) => Number.parseFloat(text.replace('$', '')));
  }
}
