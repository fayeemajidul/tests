import { expect, type Locator } from '@playwright/test';
import { BasePage } from './base.page';

export class CartPage extends BasePage {
  readonly path = '/cart.html';

  readonly title = this.page.getByTestId('title');
  readonly items = this.page.getByTestId('inventory-item');
  readonly itemNames = this.page.getByTestId('inventory-item-name');
  readonly checkoutButton = this.page.getByTestId('checkout');
  readonly continueShoppingButton = this.page.getByTestId('continue-shopping');

  async expectLoaded(): Promise<void> {
    await expect(this.title).toHaveText('Your Cart');
  }

  item(name: string): Locator {
    return this.items.filter({ hasText: name });
  }

  async removeItem(name: string): Promise<void> {
    this.log.info(`remove from cart: "${name}"`);
    await this.item(name).getByRole('button', { name: 'Remove' }).click();
  }
}
