import type { Page } from '@playwright/test';
import type { Logger } from 'winston';

/**
 * Contract for every page object:
 *  - `path` is the route relative to baseURL
 *  - `expectLoaded()` asserts the page's readiness signal (the one sanctioned in-page assertion)
 *  - action methods log what they do; assertions beyond readiness belong in specs
 */
export abstract class BasePage {
  abstract readonly path: string;

  constructor(
    protected readonly page: Page,
    protected readonly log: Logger,
  ) {}

  abstract expectLoaded(): Promise<void>;

  async goto(): Promise<void> {
    this.log.info(`navigate: ${this.path}`);
    await this.page.goto(this.path);
    await this.expectLoaded();
  }
}
