import fs from 'node:fs';
import path from 'node:path';
import winston from 'winston';

/**
 * Run-scoped winston logging.
 *
 * Layout: logs/run-<RUN_ID>/worker-<slot>.log — one interleaved, human-readable file per
 * worker slot (RUN_ID is minted once in global-setup and inherited via process.env).
 * Per-test logging is layered on top by the logger fixture, which creates a child logger
 * carrying { testName } metadata and attaches the test's own lines to the HTML report.
 */

const runId = process.env.RUN_ID ?? 'adhoc';
const workerSlot = process.env.TEST_PARALLEL_INDEX ?? 'main';
const runLogDir = path.resolve(process.cwd(), 'logs', `run-${runId}`);
fs.mkdirSync(runLogDir, { recursive: true });

export const logLine = winston.format.printf((info) => {
  const { timestamp, level, message, stack, testName, ...meta } = info as Record<string, unknown>;
  delete meta[Symbol.for('level') as unknown as string];
  const scope = typeof testName === 'string' ? ` [${testName}]` : '';
  const rest = Object.keys(meta).length > 0 ? ` ${JSON.stringify(meta)}` : '';
  const body = typeof stack === 'string' ? stack : String(message);
  return `${String(timestamp)} ${String(level).toUpperCase().padEnd(5)}${scope} ${body}${rest}`;
});

const baseFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
);

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL ?? 'info',
  format: baseFormat,
  transports: [
    new winston.transports.File({
      filename: path.join(runLogDir, `worker-${workerSlot}.log`),
      format: logLine,
    }),
    new winston.transports.Console({
      format: winston.format.combine(winston.format.colorize({ level: true }), logLine),
    }),
  ],
});
