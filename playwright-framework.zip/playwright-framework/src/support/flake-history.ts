import fs from 'node:fs';
import path from 'node:path';

/**
 * Persistence + math for the flaky reporter. History is a rolling window of RunRecords in
 * .flaky-history/history.json (gitignored locally, persisted via actions/cache in CI).
 */

export type TestOutcome = 'expected' | 'unexpected' | 'flaky' | 'skipped';

export interface AttemptRecord {
  retry: number;
  status: string;
  durationMs: number;
  error?: string;
}

export interface TestRunEntry {
  /** `project::file::title path` — stable, human-readable identity across runs */
  key: string;
  outcome: TestOutcome;
  attempts: AttemptRecord[];
}

export interface RunRecord {
  runId: string;
  startedAt: string;
  ci: boolean;
  gitSha?: string;
  branch?: string;
  tests: TestRunEntry[];
}

export interface FlakeHistory {
  version: 1;
  runs: RunRecord[];
}

export interface FlakeStat {
  key: string;
  runsSeen: number;
  flakyRuns: number;
  failedRuns: number;
  flakeRate: number;
  lastOutcome: TestOutcome;
  quarantined: boolean;
}

export function loadHistory(file: string): FlakeHistory {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8')) as FlakeHistory;
    if (parsed.version === 1 && Array.isArray(parsed.runs)) return parsed;
  } catch {
    // Missing or corrupt history is not an error — start fresh.
  }
  return { version: 1, runs: [] };
}

export function saveHistory(file: string, history: FlakeHistory): void {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(history, null, 2));
}

export function trimHistory(history: FlakeHistory, windowSize: number): FlakeHistory {
  return { version: 1, runs: history.runs.slice(-windowSize) };
}

/** Flake rate = flaky runs / runs in which the test actually executed (skips excluded). */
export function computeStats(history: FlakeHistory, quarantinedKeys: Set<string>): FlakeStat[] {
  const byKey = new Map<
    string,
    { seen: number; flaky: number; failed: number; last: TestOutcome }
  >();

  for (const run of history.runs) {
    for (const entry of run.tests) {
      if (entry.outcome === 'skipped') continue;
      const stat = byKey.get(entry.key) ?? { seen: 0, flaky: 0, failed: 0, last: entry.outcome };
      stat.seen += 1;
      if (entry.outcome === 'flaky') stat.flaky += 1;
      if (entry.outcome === 'unexpected') stat.failed += 1;
      stat.last = entry.outcome;
      byKey.set(entry.key, stat);
    }
  }

  return [...byKey.entries()]
    .map(([key, s]) => ({
      key,
      runsSeen: s.seen,
      flakyRuns: s.flaky,
      failedRuns: s.failed,
      flakeRate: s.seen > 0 ? s.flaky / s.seen : 0,
      lastOutcome: s.last,
      quarantined: isQuarantined(key, quarantinedKeys),
    }))
    .sort((a, b) => b.flakeRate - a.flakeRate || b.flakyRuns - a.flakyRuns);
}

/** Ledger keys may be exact or a prefix (e.g. omit the project to quarantine on all browsers). */
export function isQuarantined(key: string, quarantinedKeys: Set<string>): boolean {
  if (quarantinedKeys.has(key)) return true;
  for (const entry of quarantinedKeys) {
    if (key.includes(entry)) return true;
  }
  return false;
}

export interface QuarantineEntry {
  key: string;
  reason: string;
  issue?: string;
  since?: string;
  owner?: string;
}

export interface QuarantineLedger {
  version: 1;
  entries: QuarantineEntry[];
}

export function loadQuarantineLedger(file: string): QuarantineLedger {
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8')) as QuarantineLedger;
    if (parsed.version === 1 && Array.isArray(parsed.entries)) return parsed;
  } catch {
    // No ledger file is fine — nothing is quarantined.
  }
  return { version: 1, entries: [] };
}
