import fs from 'node:fs';
import path from 'node:path';

/**
 * Mints a single RUN_ID for the whole test run. Values set on process.env here are
 * inherited by every worker process, so all workers log into the same run directory.
 */
export default function globalSetup(): void {
  if (!process.env.RUN_ID) {
    process.env.RUN_ID = new Date().toISOString().replace(/[:.]/g, '-');
  }
  fs.mkdirSync(path.resolve(process.cwd(), 'logs', `run-${process.env.RUN_ID}`), {
    recursive: true,
  });
}
