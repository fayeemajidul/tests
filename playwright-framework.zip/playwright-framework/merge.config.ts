import { defineConfig } from '@playwright/test';

/**
 * Reporter set for `npx playwright merge-reports --config merge.config.ts ./all-blob-reports`
 * in sharded CI. Shards run with --reporter=blob (so the flaky reporter does NOT run
 * per-shard); this config runs it exactly once over the merged result — single writer
 * for .flaky-history/history.json.
 */
export default defineConfig({
  testDir: './tests',
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
    [
      './src/reporters/flaky-reporter.ts',
      { historyDir: '.flaky-history', windowSize: 50, quarantineFile: 'quarantine.json' },
    ],
  ],
});
