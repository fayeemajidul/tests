#!/usr/bin/env bash
# Run/update the visual suite inside the same Linux image CI uses, so committed baselines
# match CI pixel-for-pixel. Usage: scripts/docker-visual.sh [test|update]
set -euo pipefail

# Keep in lockstep with @playwright/test in package.json AND the container tag in
# .github/workflows/playwright.yml — all three move together in one PR.
IMAGE="mcr.microsoft.com/playwright:v1.62.1-noble"

case "${1:-test}" in
  test)   CMD="npx playwright test --project=visual" ;;
  update) CMD="npx playwright test --project=visual --update-snapshots=changed" ;;
  *) echo "usage: $0 [test|update]" >&2; exit 1 ;;
esac

docker run --rm --ipc=host -v "$PWD":/work -w /work -e CI=1 "$IMAGE" \
  bash -lc "npm ci && $CMD"
