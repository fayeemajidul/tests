#!/usr/bin/env node
/**
 * Interactive test runner — `npm start`.
 *
 * A guided menu for anyone using this repo: pick a suite or a specific spec file,
 * choose a browser and headed mode, and it composes the right `npx playwright test`
 * command for you (printed before it runs, so the flags are learnable).
 */
import { spawn } from 'node:child_process';
import { readdirSync } from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';

// Buffer stdin lines instead of using rl.question so answers arriving early
// (piped input, fast typists) are queued rather than dropped.
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const bufferedLines = [];
const waiters = [];
let stdinClosed = false;
rl.on('line', (line) => {
  const waiter = waiters.shift();
  if (waiter) waiter(line);
  else bufferedLines.push(line);
});
rl.on('close', () => {
  stdinClosed = true;
  for (const waiter of waiters.splice(0)) waiter(null);
});

async function ask(prompt) {
  process.stdout.write(prompt);
  const line =
    bufferedLines.length > 0
      ? bufferedLines.shift()
      : stdinClosed
        ? null
        : await new Promise((resolve) => waiters.push(resolve));
  if (line === null) {
    console.error('\nInput closed — aborting.');
    process.exit(1);
  }
  return line.trim();
}

async function choose(title, options) {
  console.log(`\n${title}`);
  options.forEach((option, index) => console.log(`  ${index + 1}. ${option}`));
  for (;;) {
    const pick = Number.parseInt(await ask('> '), 10);
    if (pick >= 1 && pick <= options.length) return pick - 1;
    console.log(`Enter a number between 1 and ${options.length}.`);
  }
}

function listSpecs() {
  return readdirSync('tests', { recursive: true, withFileTypes: true })
    .filter(
      (entry) =>
        entry.isFile() &&
        entry.name.endsWith('.spec.ts') &&
        !entry.parentPath.includes('__screenshots__'),
    )
    .map((entry) => path.join(entry.parentPath, entry.name))
    .sort();
}

const TARGETS = [
  {
    label: 'Full suite — chromium, firefox and webkit',
    args: ['--project=chromium', '--project=firefox', '--project=webkit'],
  },
  { label: 'UI suite — one browser', askBrowser: true, args: [] },
  { label: 'A specific spec file', pickSpec: true },
  { label: 'Visual regression suite', args: ['--project=visual'] },
  { label: 'Rerun last failures', args: ['--last-failed'] },
  { label: 'Quarantined tests', args: ['--project=quarantine'] },
  {
    label: 'Flaky pipeline demo (fails once, passes on retry)',
    env: { FLAKY_DEMO: '1' },
    args: ['--project=chromium', '--grep', '@flaky-demo', '--retries=2'],
  },
];

const target =
  TARGETS[
    await choose(
      'What do you want to run?',
      TARGETS.map((t) => t.label),
    )
  ];
const args = [...(target.args ?? [])];
const env = { ...process.env, ...(target.env ?? {}) };
let askBrowser = target.askBrowser ?? false;

if (target.pickSpec) {
  const specs = listSpecs();
  const spec = specs[await choose('Which spec?', specs)];
  args.push(spec);
  if (spec.includes('.visual.')) {
    args.push('--project=visual'); // visual specs only run in the visual project
    askBrowser = false;
  } else {
    askBrowser = true;
  }
}

if (askBrowser) {
  const browsers = ['chromium (fastest)', 'firefox', 'webkit', 'all three'];
  const browser = await choose('Which browser?', browsers);
  if (browser === 3) args.push('--project=chromium', '--project=firefox', '--project=webkit');
  else args.push(`--project=${['chromium', 'firefox', 'webkit'][browser]}`);
}

if (!args.includes('--project=visual')) {
  const headed = await ask('\nRun headed (watch the browser)? [y/N] ');
  if (/^y/i.test(headed)) args.push('--headed');
}

rl.close();

console.log(`\n$ npx playwright test ${args.join(' ')}\n`);
const child = spawn('npx', ['playwright', 'test', ...args], {
  stdio: 'inherit',
  env,
  shell: process.platform === 'win32',
});
child.on('exit', (code) => process.exit(code ?? 1));
