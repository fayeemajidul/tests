import { defineConfig, devices } from '@playwright/test';
import { env } from './src/config/env';

const QUARANTINE = /@quarantine/;
// Excluded from the normal browser matrix: quarantined tests (run in their own project)
// and the deterministic flaky demo. Project-level grepInvert also filters CLI --grep runs,
// so `npm run test:flaky-demo` sets FLAKY_DEMO=1 to lift its exclusion.
const EXCLUDED_TAGS = process.env.FLAKY_DEMO === '1' ? QUARANTINE : /@quarantine|@flaky-demo/;
const VISUAL_SPECS = /.*\.visual\.spec\.ts/;

export default defineConfig({
  testDir: './tests',
  globalSetup: './src/support/global-setup.ts',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  // RETRIES overrides for experiments; otherwise retry twice on CI so flaky tests are
  // detected (fail -> pass on retry = 'flaky' outcome) instead of failing the pipeline.
  retries: process.env.RETRIES ? Number(process.env.RETRIES) : process.env.CI ? 2 : 0,
  workers: process.env.CI ? '50%' : undefined,
  // Opt-in zero-tolerance mode: STRICT_FLAKY=1 fails the run if ANY test is flaky.
  // Graded enforcement lives in the flaky reporter's `budget` option instead.
  failOnFlakyTests: process.env.STRICT_FLAKY === '1',

  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
    [
      './src/reporters/flaky-reporter.ts',
      { historyDir: '.flaky-history', windowSize: 50, quarantineFile: 'quarantine.json' },
    ],
  ],

  use: {
    baseURL: env.baseUrl,
    testIdAttribute: 'data-test', // SauceDemo's attribute; change when repointing at your app
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  expect: {
    timeout: 5_000,
    toHaveScreenshot: {
      maxDiffPixelRatio: 0.01,
      animations: 'disabled',
      caret: 'hide',
      scale: 'css',
    },
  },

  // Platform-aware baselines: local macOS baselines work out of the box; Linux baselines
  // for CI are generated via the docker script or the workflow's update_snapshots input.
  snapshotPathTemplate:
    '{testDir}/visual/__screenshots__/{testFileName}/{projectName}/{platform}/{arg}{ext}',

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
      grepInvert: EXCLUDED_TAGS,
      testIgnore: VISUAL_SPECS,
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
      grepInvert: EXCLUDED_TAGS,
      testIgnore: VISUAL_SPECS,
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
      grepInvert: EXCLUDED_TAGS,
      testIgnore: VISUAL_SPECS,
    },
    {
      // Known-flaky tests keep running (and feeding flake history) without blocking the
      // main matrix; in CI this project runs in a continue-on-error job.
      name: 'quarantine',
      use: { ...devices['Desktop Chrome'] },
      grep: QUARANTINE,
      retries: 3,
      testIgnore: VISUAL_SPECS,
    },
    {
      name: 'visual',
      use: {
        ...devices['Desktop Chrome'],
        colorScheme: 'light',
        contextOptions: { reducedMotion: 'reduce' },
      },
      testMatch: VISUAL_SPECS,
      grepInvert: EXCLUDED_TAGS,
    },
  ],
});
