import { env } from '../../src/config/env';
import { expect, test } from '../../src/fixtures';

test.describe('Login', () => {
  test('standard user can sign in and reach the inventory', async ({
    loginPage,
    inventoryPage,
  }) => {
    await loginPage.goto();
    await loginPage.login(env.users.standard, env.password);

    await inventoryPage.expectLoaded();
    await expect(inventoryPage.items.first()).toBeVisible();
  });

  test('locked out user sees an actionable error', async ({ loginPage }) => {
    await loginPage.goto();
    await loginPage.login(env.users.lockedOut, env.password);

    await expect(loginPage.errorMessage).toContainText('locked out');
  });

  test('wrong password is rejected', async ({ loginPage }) => {
    await loginPage.goto();
    await loginPage.login(env.users.standard, 'not-the-password');

    await expect(loginPage.errorMessage).toContainText('do not match');
  });
});
