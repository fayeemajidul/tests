import { env } from '../../src/config/env';
import { expect, test } from '../../src/fixtures';

test.describe('Cart', () => {
  test.beforeEach(async ({ loginPage, inventoryPage }) => {
    await loginPage.goto();
    await loginPage.login(env.users.standard, env.password);
    await inventoryPage.expectLoaded();
  });

  test('items added on the inventory page appear in the cart', async ({
    inventoryPage,
    cartPage,
  }) => {
    await inventoryPage.addToCart('Sauce Labs Backpack');
    await inventoryPage.addToCart('Sauce Labs Onesie');
    await inventoryPage.openCart();

    await cartPage.expectLoaded();
    await expect(cartPage.items).toHaveCount(2);
    await expect(cartPage.itemNames).toHaveText(['Sauce Labs Backpack', 'Sauce Labs Onesie']);
  });

  test('removing an item from the cart updates the list', async ({ inventoryPage, cartPage }) => {
    await inventoryPage.addToCart('Sauce Labs Backpack');
    await inventoryPage.addToCart('Sauce Labs Onesie');
    await inventoryPage.openCart();
    await cartPage.expectLoaded();

    await cartPage.removeItem('Sauce Labs Backpack');

    await expect(cartPage.items).toHaveCount(1);
    await expect(cartPage.item('Sauce Labs Onesie')).toBeVisible();
    await expect(cartPage.checkoutButton).toBeEnabled();
  });
});
