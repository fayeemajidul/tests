import { expect, test } from '../../src/fixtures';

/**
 * Deterministic flaky test: fails on attempt 0, passes on retry. It exists to demonstrate
 * and verify the whole flaky pipeline (retry -> outcome 'flaky' -> history -> summary).
 * Excluded from the normal browser matrix; run it with `npm run test:flaky-demo`.
 */
test(
  'flaky demo: fails first attempt, passes on retry',
  { tag: '@flaky-demo' },
  async ({ loginPage, log }, testInfo) => {
    await loginPage.goto();

    // eslint-disable-next-line playwright/no-conditional-in-test -- deliberate: simulates a flake deterministically
    if (testInfo.retry === 0) {
      log.warn('simulating a first-attempt failure to exercise the flaky pipeline');
      throw new Error('Deliberate first-attempt failure (flaky pipeline demo)');
    }

    await expect(loginPage.loginButton).toBeVisible();
  },
);
