import { env } from '../../src/config/env';
import { expect, test } from '../../src/fixtures';

test.describe('Inventory', () => {
  test.beforeEach(async ({ loginPage, inventoryPage }) => {
    await loginPage.goto();
    await loginPage.login(env.users.standard, env.password);
    await inventoryPage.expectLoaded();
  });

  test('sorting by price low-to-high orders the grid ascending', async ({ inventoryPage }) => {
    await inventoryPage.sortBy('lohi');

    const prices = await inventoryPage.visiblePrices();
    expect(prices.length).toBeGreaterThan(0);
    expect(prices).toEqual([...prices].sort((a, b) => a - b));
  });

  test('sorting by name Z-to-A orders the grid descending', async ({ inventoryPage }) => {
    await inventoryPage.sortBy('za');

    const names = await inventoryPage.visibleNames();
    expect(names.length).toBeGreaterThan(0);
    expect(names).toEqual([...names].sort().reverse());
  });

  test('adding and removing items updates the cart badge', async ({ inventoryPage }) => {
    await inventoryPage.addToCart('Sauce Labs Backpack');
    await expect(inventoryPage.cartBadge).toHaveText('1');

    await inventoryPage.addToCart('Sauce Labs Bike Light');
    await expect(inventoryPage.cartBadge).toHaveText('2');

    await inventoryPage.removeFromCart('Sauce Labs Backpack');
    await expect(inventoryPage.cartBadge).toHaveText('1');
  });
});
