import { env } from '../../src/config/env';
import { expect, test } from '../../src/fixtures';

test.describe('Storefront visuals', () => {
  test('login page renders correctly', async ({ loginPage, page }) => {
    await loginPage.goto();

    await expect(page).toHaveScreenshot('login-page.png', { fullPage: true });
  });

  test('inventory grid renders correctly', async ({ loginPage, inventoryPage, page }) => {
    await loginPage.goto();
    await loginPage.login(env.users.standard, env.password);
    await inventoryPage.expectLoaded();

    // Mask example for dynamic regions — the badge changes with cart state.
    await expect(page).toHaveScreenshot('inventory-grid.png', {
      fullPage: true,
      mask: [inventoryPage.cartBadge],
      maskColor: '#FF00FF',
    });
  });
});
